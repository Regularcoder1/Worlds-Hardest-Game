var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["848314f8-d7dc-4755-a4a1-3782173096b1","26b80e63-bc0f-408d-b288-be2282aebd4e","c4e310e0-8174-4127-a46e-0cbcc94b488b","47880765-e7c6-47e6-b637-6cf6c68d698e","7a8c1420-b592-4582-bfe9-81a31ad255fd","e11884e7-39fb-4d91-97a1-87147afeb953","690f0b84-0689-476d-a7f0-1bd4c9d5e1bb","80c10e4b-57c7-4e96-866b-8a91cd1921a9"],"propsByKey":{"848314f8-d7dc-4755-a4a1-3782173096b1":{"name":"hero","sourceUrl":null,"frameSize":{"x":30,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"Q4S4BfGWVe0_zA9Wl_iAt_vmBNkDVGrF","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":30},"rootRelativePath":"assets/848314f8-d7dc-4755-a4a1-3782173096b1.png"},"26b80e63-bc0f-408d-b288-be2282aebd4e":{"name":"enemy1","sourceUrl":null,"frameSize":{"x":35,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"UKKj1Q2smLuPOw8zL1iqBkG0FuMu1q_5","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":35,"y":50},"rootRelativePath":"assets/26b80e63-bc0f-408d-b288-be2282aebd4e.png"},"c4e310e0-8174-4127-a46e-0cbcc94b488b":{"name":"dream","sourceUrl":null,"frameSize":{"x":386,"y":268},"frameCount":1,"looping":true,"frameDelay":12,"version":"HKHU38rEcjcwn5orfYO5MCGOVCL9zX4z","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":386,"y":268},"rootRelativePath":"assets/c4e310e0-8174-4127-a46e-0cbcc94b488b.png"},"47880765-e7c6-47e6-b637-6cf6c68d698e":{"name":"b","sourceUrl":"assets/api/v1/animation-library/gamelab/uexnVGl6IX_C6YzQENPPXtel_lCwoG7F/category_backgrounds/desert_road.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"uexnVGl6IX_C6YzQENPPXtel_lCwoG7F","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/uexnVGl6IX_C6YzQENPPXtel_lCwoG7F/category_backgrounds/desert_road.png"},"7a8c1420-b592-4582-bfe9-81a31ad255fd":{"name":"enemy3","sourceUrl":"assets/api/v1/animation-library/gamelab/i.TOUie12cy0KbasjKdp6IWoFSTZDYCk/category_animals/animalhead_fox.png","frameSize":{"x":306,"y":316},"frameCount":1,"looping":true,"frameDelay":2,"version":"i.TOUie12cy0KbasjKdp6IWoFSTZDYCk","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":306,"y":316},"rootRelativePath":"assets/api/v1/animation-library/gamelab/i.TOUie12cy0KbasjKdp6IWoFSTZDYCk/category_animals/animalhead_fox.png"},"e11884e7-39fb-4d91-97a1-87147afeb953":{"name":"enemy2","sourceUrl":"assets/api/v1/animation-library/gamelab/jlPzhEsGcu.O9CRbuWaGOy51uwI14RV./category_animals/animalhead_sabertooth.png","frameSize":{"x":350,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"jlPzhEsGcu.O9CRbuWaGOy51uwI14RV.","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":350,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/jlPzhEsGcu.O9CRbuWaGOy51uwI14RV./category_animals/animalhead_sabertooth.png"},"690f0b84-0689-476d-a7f0-1bd4c9d5e1bb":{"name":"hero1","sourceUrl":"assets/api/v1/animation-library/gamelab/yOoQ.InHE8bOjY27rcFKf7ZX9YZuesU2/category_animals/animalhead_rabbit.png","frameSize":{"x":302,"y":386},"frameCount":1,"looping":true,"frameDelay":2,"version":"yOoQ.InHE8bOjY27rcFKf7ZX9YZuesU2","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":302,"y":386},"rootRelativePath":"assets/api/v1/animation-library/gamelab/yOoQ.InHE8bOjY27rcFKf7ZX9YZuesU2/category_animals/animalhead_rabbit.png"},"80c10e4b-57c7-4e96-866b-8a91cd1921a9":{"name":"enemy","sourceUrl":"assets/api/v1/animation-library/gamelab/PalIH3yhEDuaXk29er5W2Hwc2U9pdJFV/category_animals/animalhead_lion.png","frameSize":{"x":400,"y":380},"frameCount":1,"looping":true,"frameDelay":2,"version":"PalIH3yhEDuaXk29er5W2Hwc2U9pdJFV","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":380},"rootRelativePath":"assets/api/v1/animation-library/gamelab/PalIH3yhEDuaXk29er5W2Hwc2U9pdJFV/category_animals/animalhead_lion.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var b = createSprite(200,200);
 b.setAnimation("b");
var hero = createSprite(200,345,200,345);
hero.shapeColor="red";

var enemy1 = createSprite(200,250,10,10);
enemy1.shapeColor="red";

var enemy2 = createSprite(200,150,10,10);
enemy2.shapeColor="red";

var enemy3 = createSprite(200,50,10,10);
enemy3.shapeColor="red";

var net = createSprite(200,5,200,20);
net.shapeColor="red";

var goal =0;
var death = 0;
createSprite(312,4,50,40);

hero.setAnimation("hero1");
hero.scale=.2;
enemy1.setAnimation("enemy");
enemy1.scale=.2;
enemy2.setAnimation("enemy2");
enemy2.scale=.2;
enemy3.setAnimation("enemy3");
enemy3.scale=.2;

enemy1.setVelocity(-10,0);
enemy2.setVelocity(10,0);
enemy3.setVelocity(-10,0);


function draw() {
  
//background(b);

createEdgeSprites()




enemy1.bounceOff(edges)
enemy2.bounceOff(edges)
enemy3.bounceOff(edges)

if(keyDown(UP_ARROW)){
  hero.y=hero.y-3
}

if(keyDown(DOWN_ARROW)){
  hero.y=hero.y+3
}

if(keyDown(LEFT_ARROW)){
  hero.x=hero.x-3
}

if(keyDown(RIGHT_ARROW)){
  hero.x=hero.x+3
}

if(hero.isTouching(enemy1)|| hero.isTouching(enemy2)|| hero.isTouching(enemy3)){
  playSound("assets/category_achievements/bubbly_game_achievement_sound.mp3")
  hero.x=200
  hero.y=350
  death = death+1
}
if(hero.isTouching(net)){
  playSound("assets/category_achievements/vibrant_game_game_gold_tresure_chest_open.mp3")
  hero.x=200
  hero.y=345
  goal=goal+1
}
if (hero.isTouching(enemy1||enemy2||enemy3))
score=-1
textSize(20)
  fill("blue")
  text("Goals:"+goal,320,350);
  

textSize(20)
  fill("blue")
  text("death:"+death,20,350);
  
drawSprites()
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
